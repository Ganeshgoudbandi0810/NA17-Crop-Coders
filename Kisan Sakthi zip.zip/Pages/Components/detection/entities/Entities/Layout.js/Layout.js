
import React from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Camera, BookOpen, History, Settings, Languages, Home } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const navigationItems = [
  {
    title: "Home",
    url: createPageUrl("Home"),
    icon: Home,
  },
  {
    title: "Disease Detection",
    url: createPageUrl("Detection"),
    icon: Camera,
  },
  {
    title: "Knowledge Base",
    url: createPageUrl("KnowledgeBase"),
    icon: BookOpen,
  },
  {
    title: "My History",
    url: createPageUrl("History"),
    icon: History,
  },
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [language, setLanguage] = React.useState(
    localStorage.getItem('kisanLanguage') || 'english'
  );

  const toggleLanguage = () => {
    const newLang = language === 'english' ? 'telugu' : 'english';
    setLanguage(newLang);
    localStorage.setItem('kisanLanguage', newLang);
  };

  const getText = (en, te) => language === 'telugu' ? te : en;

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50">
        <Sidebar className="border-r border-green-100 bg-white/80 backdrop-blur-sm">
          <SidebarHeader className="border-b border-green-100 p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-600 rounded-xl flex items-center justify-center shadow-lg">
                <span className="text-white font-bold text-lg">🌾</span>
              </div>
              <div>
                <h2 className="font-bold text-green-900 text-lg">
                  {getText("Kisan Sakthi", "కిసాన్ శక్తి")}
                </h2>
                <p className="text-xs text-green-600">
                  {getText("AI Crop Doctor", "AI పంట వైద్యుడు")}
                </p>
              </div>
            </div>
          </SidebarHeader>
          
          <SidebarContent className="p-2">
            <SidebarGroup>
              <SidebarGroupLabel className="text-xs font-medium text-green-700 uppercase tracking-wider px-2 py-2">
                {getText("Navigation", "నావిగేషన్")}
              </SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {navigationItems.map((item) => (
                    <SidebarMenuItem key={item.title}>
                      <SidebarMenuButton 
                        asChild 
                        className={`hover:bg-green-50 hover:text-green-700 transition-colors duration-200 rounded-lg mb-1 ${
                          location.pathname === item.url ? 'bg-green-50 text-green-700' : ''
                        }`}
                      >
                        <Link to={item.url} className="flex items-center gap-3 px-3 py-2">
                          <item.icon className="w-4 h-4" />
                          <span className="font-medium">
                            {item.title === "Home" && getText("Home", "హోమ్")}
                            {item.title === "Disease Detection" && getText("Disease Detection", "వ్యాధి గుర్తింపు")}
                            {item.title === "Knowledge Base" && getText("Knowledge Base", "జ్ఞాన భాండాగారం")}
                            {item.title === "My History" && getText("My History", "నా చరిత్ర")}
                            {!["Home", "Disease Detection", "Knowledge Base", "My History"].includes(item.title) && item.title}
                          </span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>

            <SidebarGroup>
              <SidebarGroupContent>
                <div className="px-3 py-4">
                  <button
                    onClick={toggleLanguage}
                    className="flex items-center gap-2 w-full p-2 text-sm bg-green-100 text-green-800 rounded-lg hover:bg-green-200 transition-colors"
                  >
                    <Languages className="w-4 h-4" />
                    <span className="font-medium">
                      {language === 'english' ? 'తెలుగు' : 'English'}
                    </span>
                  </button>
                </div>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-green-100 p-4">
            <div className="bg-gradient-to-r from-green-100 to-emerald-100 rounded-xl p-3">
              <p className="text-xs text-green-700 font-medium">
                {getText("Powered by AI", "AI ద్వారా శక్తివంతం")}
              </p>
              <p className="text-xs text-green-600">
                {getText("For healthy crops", "ఆరోగ్యకరమైన పంటల కోసం")}
              </p>
            </div>
          </SidebarFooter>
        </Sidebar>

        <main className="flex-1 flex flex-col">
          <header className="bg-white/80 backdrop-blur-sm border-b border-green-100 px-6 py-4 md:hidden">
            <div className="flex items-center gap-4">
              <SidebarTrigger className="hover:bg-green-50 p-2 rounded-lg transition-colors duration-200" />
              <h1 className="text-xl font-bold text-green-900">
                {getText("Kisan Sakthi", "కిసాన్ శక్తి")}
              </h1>
            </div>
          </header>

          <div className="flex-1 overflow-auto">
            <div className="language-provider" data-language={language}>
              {children}
            </div>
          </div>
        </main>
      </div>
    </SidebarProvider>
  );
}
